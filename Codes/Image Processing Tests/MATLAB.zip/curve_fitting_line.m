clear all;
clc;

x = [1 2 3 4 5 6 7];
y = [.5 2.5 2 4 3.5 6 5.5];

sumx = 0;
sumy = 0;
sumxy= 0;
sumxsq=0;
for i=1:7
    sumx = sumx + x(i);
    sumy = sumy + y(i);
    sumxy= sumxy+ x(i)*y(i);
    sumxsq=sumxsq +x(i)*x(i);
end

format long;

a1 = (7*sumxy-sumx*sumy)/(7*sumxsq-sumx*sumx);
a0 = sumy/7-a1*sumx/7;

plot(x,y,'o')
hold on;

ym = a0 + a1*x ;
plot(x,ym);
