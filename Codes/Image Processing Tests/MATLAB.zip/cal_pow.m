function y=cal_pow(n);
    y = n*n + 1;
end