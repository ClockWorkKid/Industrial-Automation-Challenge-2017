clc;
clear all;

x = 1:.1:10 ;
y = sin(x);
z = x + y;