clear all;
clc;

x = [0 1 2 3 4 5 6];
y = [0 .8415 .9093 .1411 -.7568 -.9589 -.2794];

poly = [0];
for i=1:7
    P = [1] ;
    for j=1:7
        if j~= i
            P = conv(P,[1 -(x(j))])/(x(i) - (x(j)));
        end
    end
        poly = poly + P*y(i) ;
end

X = 0:.01:6 ;
plot(X, polyval(poly,X));
a = polyval(poly,2.5);
display(a);